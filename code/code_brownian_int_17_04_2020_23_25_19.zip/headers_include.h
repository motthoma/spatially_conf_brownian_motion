/*file that serves as a wrapper for various headers that are 
 *written by a code generator. Headers include the one for the  mpi 
 *lib for parallelization and the ones that are specific 
 *to inter-particle interactions and confinements.
 */

#include "int_hardspheres.h"
//#include "int_lennardjones.h"

#include "conf_splitter.h"
//#include "conf_sept.h"
//#include "conf_cos.h"

//#define MPI_ON
