"""

Script that helps to create makefile
for the compilation of brownian motion
code.

It presents the possible files for 
confinements and interactions and composes
the makefile based on the user's choices.

"""
import os

def get_confinement_files():

	files = [f for f in os.listdir('.') if os.path.isfile(f) and f.endswith('.c')]
	conf_files = [f for f in files if f.startswith('conf')]

	print("\n\nList of possible confinments:\n")	
	for ind, element in enumerate(conf_files):
		print("{}: {}".format(ind, element))
	
	try:
		zip_in = raw_input(file_select_request) 
	except:
		zip_in = input(file_select_request)
	
	return conf_files

def get_interaction_files():

	files = [f for f in os.listdir('.') if os.path.isfile(f) and f.endswith('.c')]
	int_files = [f for f in files if f.startswith('int')]
	
	print("\n\nList of possible interactions:\n")	
	for ind, element in enumerate(int_files):
		print("{}: {}".format(ind, element))
	
	return int_files
		

	

if __name__ == "__main__":

	conf_files = get_confinement_files()
	

	int_files = get_interaction_files()		
